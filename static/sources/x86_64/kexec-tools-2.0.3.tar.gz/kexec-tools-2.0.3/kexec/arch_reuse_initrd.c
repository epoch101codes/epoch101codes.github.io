#include "kexec.h"

void arch_reuse_initrd(void)
{
	die("--reuseinitrd not implemented on this architecture\n");
}
