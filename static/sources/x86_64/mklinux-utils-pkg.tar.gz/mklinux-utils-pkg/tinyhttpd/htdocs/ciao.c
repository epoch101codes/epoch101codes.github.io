 
#include <stdio.h>

int main()
{
  printf("ciao ciao ciao\n");
  return 0;
}
